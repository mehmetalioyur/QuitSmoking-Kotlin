package com.mehmetalioyur.quitsmoking

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mehmetalioyur.quitsmoking.databinding.FragmentSettingsBinding
import com.mehmetalioyur.quitsmoking.databinding.FragmentSuccessesBinding
import java.util.*
import java.util.concurrent.TimeUnit


class SuccessesFragment : Fragment() {

    private var _binding: FragmentSuccessesBinding? = null
    private val binding get() = _binding!!
    val calendar = Calendar.getInstance()

    var savedMinute: Int? = null
    var savedHour: Int? = null
    var savedDay: Int? = null
    var savedMonth: Int? = null
    var savedYear: Int? = null

    var handler = Handler(Looper.getMainLooper())
    var runnable = kotlinx.coroutines.Runnable { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSuccessesBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val savedDate = setCalender()

        runnable = object : Runnable {
            override fun run() {

                val millionSeconds = Calendar.getInstance().timeInMillis - savedDate!!.timeInMillis
                val timeDifference = TimeUnit.MILLISECONDS.toSeconds(millionSeconds)

                var progressOne = (timeDifference * 100 / (1200)).toInt()
                var progressTwo = (timeDifference * 100 / (28800)).toInt()
                var progressThree = (timeDifference * 100 / (86400)).toInt()
                var progressFour = (timeDifference * 100 / (86400 * 2)).toInt()
                var progressFive = (timeDifference * 100 / (3628800)).toInt()
                var progressSix = (timeDifference * 100 / (15552000)).toInt()
                var progressSeven = (timeDifference * 100 / (31536000)).toInt()

                binding.firstProgress.progress = progressOne
                binding.secondProgress.progress = progressTwo
                binding.thirdProgress.progress = progressThree
                binding.fourthProgress.progress = progressFour
                binding.fifthProgress.progress = progressFive
                binding.sixthProgress.progress = progressSix
                binding.seventhProgress.progress = progressSeven

                var progressList = arrayOf(
                    progressOne,
                    progressTwo,
                    progressThree,
                    progressFour,
                    progressFive,
                    progressSix,
                    progressSeven
                )

                var texts =arrayOf(binding.firstText,binding.secondText,binding.thirdText,binding.fourthText,binding.fifthText,binding.sixthText,binding.seventhText)

                for (i in progressList.indices) {

                    if (progressList[i] < 100) {
                        texts[i].text = "${progressList[i]}%"
                    }
                    else{
                        println("girdim")
                        texts[i].text = "100%"
                    }
                }


                handler.postDelayed(runnable, 1000)
            }
        }
        handler.post(runnable)


    }

    fun setCalender(): Calendar? {
        arguments?.let {
            savedYear = SuccessesFragmentArgs.fromBundle(it).savedYear
            savedMonth = SuccessesFragmentArgs.fromBundle(it).savedMonth
            savedDay = SuccessesFragmentArgs.fromBundle(it).savedDay
            savedHour = SuccessesFragmentArgs.fromBundle(it).savedHour
            savedMinute = SuccessesFragmentArgs.fromBundle(it).savedMinute

            calendar.set(savedYear!!, savedMonth!!, savedDay!!, savedHour!!, savedMinute!!)


        }

        return calendar
    }


    override fun onDestroyView() {

        super.onDestroyView()
        handler.removeCallbacks(runnable)
        _binding = null

    }
}